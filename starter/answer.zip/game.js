

const Bejeweled = require("./class/bejeweled");

bejeweled = new Bejeweled();
